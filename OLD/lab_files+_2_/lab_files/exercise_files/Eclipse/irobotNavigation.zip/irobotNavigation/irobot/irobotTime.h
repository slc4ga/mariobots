#ifndef IROBOT_TIME_H
#define IROBOT_TIME_H

#include <stdint.h>

/* delay a fixed number of milliseconds */
void irobotDelayMs(const int32_t ms);


#endif /* IROBOT_TIME_H */
